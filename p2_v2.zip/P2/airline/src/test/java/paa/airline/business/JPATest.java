package paa.airline.business;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import paa.airline.business.JPAAirlineService;
import paa.airline.model.AircraftType;
import paa.airline.model.Airport;
import paa.airline.model.Flight;
import paa.airline.model.Ticket;
import paa.airline.util.AirportQuery;
import paa.airline.business.AirlineServiceException;

public class JPATest {
	
	/*
	 * @BeforeEach, AfterEach, AfterAll, BeforeAll, Disabled, DisplayName
	 */

    @Test
    void testCreateAirport() throws AirlineServiceException
    {
        JPAAirlineService jpa_as = new JPAAirlineService();
        Airport b = new Airport("MAD", "Madrid", "Barajas", 5, 10);

        assertNotNull(b);
        assertDoesNotThrow(() -> 
        b.equals(jpa_as.createAirport(b.getIataCode(), b.getCityName(), b.getAirportName(), b.getLongitude(), b.getLatitude()))
        );
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAirport("mAD", "Madrid", "", -200, 0);
            jpa_as.createAirport("MAD", "md", "Barajas", 5, 10);
            jpa_as.createAirport("mAD", "Madrid", "Barajas", 0, 0);
            jpa_as.createAirport("mAD", "Madrid", "Barajas", -200, 0);
            jpa_as.createAirport("mAD", "", "Barajas", -200, 0);
        });
        
    }

    @Test
    void testListAirport() throws AirlineServiceException{

        JPAAirlineService jpa_as = new JPAAirlineService();
        jpa_as.createAirport("AAA", "CiudadA", "Aeropuerto1", 4, 6);
        jpa_as.createAirport("BBB", "CiudadB", "Aeropuerto2", 4, 6);
        jpa_as.createAirport("CCC", "CiudadC", "Aeropuerto3", 4, 6);
        jpa_as.createAirport("DDD", "CiudadD", "Aeropuerto4", 4, 6);
        jpa_as.createAirport("EEE", "CiudadE", "Aeropuerto5", 4, 6);
        jpa_as.createAirport("FFF", "CiudadF", "Aeropuerto6", 4, 6);
        jpa_as.createAirport("GGG", "CiudadG", "Aeropuerto7", 4, 6);
        List<Airport> lista = jpa_as.listAirports();
        for (Airport airport : lista) {
            System.out.println(airport.getAirportName());
        }
    }

    @Test
    void createAircraftTypeTest() throws AirlineServiceException{
        JPAAirlineService jpa_as = new JPAAirlineService();

        assertDoesNotThrow(() ->
        {
            jpa_as.createAircraft("Manufacturer1", "Model1", 30, 0);
            jpa_as.createAircraft("Manufacturer2", "Model2", 1, 0);
            jpa_as.createAircraft("Manufacturer3", "Model3", 15, 5);
            jpa_as.createAircraft("Manufacturer4", "Model4", 100, 99);
        });
        
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", null, 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft(null, "Model", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("", "Model", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufaturer", "", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", "Model", 0, 10);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", "Model", -10, 0);
        });
    
    }

    @Test
    void listAircraftTypes() throws AirlineServiceException {
        JPAAirlineService jpa_as = new JPAAirlineService();

        List<AircraftType> lista_test = new ArrayList<>();
        assertDoesNotThrow(() ->{
            AircraftType a = jpa_as.createAircraft("Manufacturer1", "Model1", 30, 0);
            AircraftType b = jpa_as.createAircraft("Manufacturer2", "Model2", 1, 0);
            AircraftType c = jpa_as.createAircraft("Manufacturer3", "Model3", 15, 5);
            AircraftType d = jpa_as.createAircraft("Manufacturer4", "Model4", 100, 99);
            lista_test.add(a);
            lista_test.add(b);
            lista_test.add(c);
            lista_test.add(d);
        });
        assertTrue(lista_test.equals(jpa_as.listAircraftTypes()));
    }

    @Test
    void createFlightTest() throws AirlineServiceException{

        JPAAirlineService as_jpa = new JPAAirlineService();
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        
        assertDoesNotThrow(() ->
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
            as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        });
        
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(null, aeropuerto_A.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(),null , avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), null);
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight("EEE", aeropuerto_B.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), "EEE", avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), 123456L);
        });

    }

    @Test
    void findFlightTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();

        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        assertTrue(a.equals(as_jpa.findFlight(a.getFlightNumber())));
        assertTrue(b.equals(as_jpa.findFlight(b.getFlightNumber())));
        assertEquals(b, as_jpa.findFlight(b.getFlightNumber()));
        assertNotEquals(a, b);
    }

    @Test
    void listFlightsTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        Airport aeropuerto_C = as_jpa.createAirport("CCC", "CiudadC", "AeropuertoC", 10, 10);

        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        Flight c = as_jpa.createFlight(aeropuerto_C.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        Flight d = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_C.getIataCode(), avion.getId());
        Flight e = as_jpa.createFlight(aeropuerto_C.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight f = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_C.getIataCode(), avion.getId());

        List<Flight> lista_test = new ArrayList<>();
        lista_test.add(a);
        lista_test.add(b);
        lista_test.add(c);
        lista_test.add(d);
        lista_test.add(e);
        lista_test.add(f);

        assertEquals(lista_test, as_jpa.listFlights());
    }

    @Test
    void purchaseTicketTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();

        
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 2, 2);
        
        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        
        
        assertDoesNotThrow(() -> {
            as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());

        });
        assertThrows(AirlineServiceException.class, () -> {
            as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        });

        assertDoesNotThrow(() -> {
            as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
            as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        });
        assertThrows(AirlineServiceException.class, () -> {
            as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        });
        
        //Hay que actualizar el objeto para conseguir los datos 
        List<Ticket> t_lista = as_jpa.findFlight(a.getFlightNumber()).getTickets();
        System.out.println("\n\nTEST\n\n" + t_lista.size());
        System.out.println(t_lista);

    }

    @Test
    void availableSeatsTest() throws AirlineServiceException{

        JPAAirlineService as_jpa = new JPAAirlineService();

        
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 3, 3);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        System.out.println(as_jpa.availableSeats(a.getFlightNumber(), LocalDate.now()));

        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());

        System.out.println(as_jpa.availableSeats(a.getFlightNumber(), LocalDate.now()));
    }

    @Test
    void cancelTicketTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();

        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 4, 4);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 4, 4);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 4, 4);

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        Ticket t_1 = as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        Ticket t_2 = as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now().plusDays(5));
        Ticket t_3 = as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now().plusDays(10));
        Ticket t_4 = as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now().minusDays(1));
        Ticket t_5 = as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());


        a = as_jpa.findFlight(a.getFlightNumber());

        assertTrue(a.getTickets().size() == 5);

        as_jpa.cancelTicket(t_1.getTicketNumber(), LocalDate.now());
        as_jpa.cancelTicket(t_2.getTicketNumber(), LocalDate.now().plusDays(5));

        a = as_jpa.findFlight(a.getFlightNumber());

        assertTrue(a.getTickets().size() == 3);

    }

    @Test
    void api_test() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();
        String iata_mad = "MAD";
        String iata_bcn = "BCN";


        Airport a_mad = as_jpa.createAirport(iata_mad, AirportQuery.getName(iata_mad), AirportQuery.getLocation(iata_mad),
        AirportQuery.getLongitude(iata_mad), AirportQuery.getLatitude(iata_mad));

        Airport a_bcn = as_jpa.createAirport(iata_bcn, AirportQuery.getName(iata_bcn), AirportQuery.getLocation(iata_bcn),
        AirportQuery.getLongitude(iata_bcn), AirportQuery.getLatitude(iata_bcn));

        //AircraftType aircraftType = new AircraftType("manu", "model", 20, 20); NO HACER, actuar con la capa de negocio para crear
        AircraftType aircraftType =  as_jpa.createAircraft("manu", "model", 20, 20);


        Flight flight = as_jpa.createFlight(iata_mad, iata_bcn, aircraftType.getId());

        //Ticket t = new Ticket("Nombre", "Apellido", 0, 0, null, 0, flight)
        /*
        as_jpa.purchaseTicket("Nombre: 0", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(0), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 1", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(1), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 5", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(5), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 9", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(9), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 10", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(10), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 11", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(11), LocalDate.now());
        as_jpa.purchaseTicket("Nombre: 20", "Apellido", flight.getFlightNumber(), LocalDate.now().minusDays(20), LocalDate.now());
         * 
         */

        for (int i = 50; i >= 0; i--) {
            as_jpa.purchaseTicket("Nombre" + i, " dias restantes: " + i, flight.getFlightNumber(), LocalDate.now().minusDays(i), LocalDate.now());
        }


    }

    @Test
    void list_test() throws AirlineServiceException{
        
        JPAAirlineService as_jpa = new JPAAirlineService();
        String iata_mad = "MAD";
        String iata_bcn = "BCN";
        String iata_agp = "AGP";
        Random random = new Random();


        Airport a_mad = as_jpa.createAirport(iata_mad, AirportQuery.getName(iata_mad), AirportQuery.getLocation(iata_mad),
        AirportQuery.getLongitude(iata_mad), AirportQuery.getLatitude(iata_mad));

        Airport a_bcn = as_jpa.createAirport(iata_bcn, AirportQuery.getName(iata_bcn), AirportQuery.getLocation(iata_bcn),
        AirportQuery.getLongitude(iata_bcn), AirportQuery.getLatitude(iata_bcn));

        Airport a_agp = as_jpa.createAirport(iata_agp, AirportQuery.getName(iata_agp), AirportQuery.getLocation(iata_agp),
        AirportQuery.getLongitude(iata_agp), AirportQuery.getLatitude(iata_agp));
        AircraftType aircraftType =  as_jpa.createAircraft("manu", "model", 20, 20);


        Flight flight = as_jpa.createFlight(iata_mad, iata_agp, aircraftType.getId());
        Flight flight2 = as_jpa.createFlight(iata_bcn, iata_agp, aircraftType.getId());
        Flight flight3 = as_jpa.createFlight(iata_agp, iata_mad, aircraftType.getId());

        for (int i = 5; i >= 0; i--) {
            as_jpa.purchaseTicket("Nombre" + i, " dias restantes: " + i, flight.getFlightNumber(), LocalDate.now().minusDays(0), LocalDate.now().plusDays(random.nextInt(5)));
        }
        for (int i = 5; i >= 0; i--) {
            as_jpa.purchaseTicket("Nombre" + i, " dias restantes: " + i, flight2.getFlightNumber(), LocalDate.now().minusDays(0), LocalDate.now().plusDays(random.nextInt(5)));
        }
        for (int i = 5; i >= 0; i--) {
            as_jpa.purchaseTicket("Nombre" + i, " dias restantes: " + i, flight3.getFlightNumber(), LocalDate.now().minusDays(0), LocalDate.now().plusDays(random.nextInt(5)));
        }


        System.out.println(        as_jpa.listTicketOrderBy());


    }


}


/*
 * DUDAS 
 * Por que en airportQuery se usan metodos static
 * 
 * Como obtenemos el multiplicador
 * 
 * Trush es realmente a partir de qué dia empieza a subir el precios
 * 
 * Es normal que en la bdd los id no siempre empiecen por 0
 * 
 * Diapositiva 19 -> Define e instancia en la misma clase
 */