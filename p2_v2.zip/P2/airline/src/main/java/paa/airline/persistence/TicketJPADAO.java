package paa.airline.persistence;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import paa.airline.model.Ticket;

public class TicketJPADAO extends JPADAO<Ticket, Long>{

    public TicketJPADAO(EntityManager em, Class<Ticket> entityClass) {
        super(em, entityClass);
        //TODO Auto-generated constructor stub
    }
    
    public List<Ticket> findByDate(LocalDate date, Long flightNumber){
        //Encontrar objetos de tipo Ticket para una fecha y un numero de vuelo dado
        String jpql = "SELECT t FROM " + clazz.getSimpleName() + " t WHERE t.flightDate = :date AND t.flight.flightNumber = :flightNumber";
        TypedQuery<Ticket> query = em.createQuery(jpql, clazz);
        query.setParameter("date", date);
        query.setParameter("flightNumber", flightNumber);
        return query.getResultList();
    }

    public List<Ticket> findAllTicketsSortedByDate(){

        //String jpql = "SELECT t FROM " + clazz.getSimpleName() + " t WHERE t.flightDate ORDER BY t.flightDate";
        String jpql = "SELECT t FROM " + clazz.getSimpleName() + " ORDER BY t.flightDate";
        TypedQuery<Ticket> query = em.createQuery(jpql, clazz);

        return query.getResultList();
    }
}


