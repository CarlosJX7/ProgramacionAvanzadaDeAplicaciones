package paa.airline.persistence;

import javax.persistence.EntityManager;

import paa.airline.model.AircraftType;

public class AircraftTypeJPADAO extends JPADAO<AircraftType, Long>{

    public AircraftTypeJPADAO(EntityManager em, Class<AircraftType> entityClass) {
        super(em, entityClass);
        //TODO Auto-generated constructor stub
    }


    
}
