package paa.airline.business;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import paa.airline.model.AircraftType;
import paa.airline.model.Airport;
import paa.airline.model.Flight;
import paa.airline.model.Ticket;
import paa.airline.persistence.AircraftTypeJPADAO;
import paa.airline.persistence.AirportJPADAO;
import paa.airline.persistence.FlightJPADAO;
import paa.airline.persistence.TicketJPADAO;
import paa.airline.util.AirportQuery;

/*
 * En las operaciones, hace uso del resto de los DAOs y lo gestiona mediante transacciones
 * ¿?Las transacciones las hacemos aqui porque sino en los JPADAOs se nos acumularian
 */
public class JPAAirlineService implements AirlineService{
    private static final String PERSISTENCE_UNIT_NAME = "perico";
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

    @Override
    public Airport createAirport(String iataCode, String cityName, String airportName, double longitude,
            double latitude) throws AirlineServiceException {
                
        if (!airportNameCheck(iataCode, cityName, airportName, longitude, latitude)) {
            throw new AirlineServiceException("Error en los parametros del aeropuerto");    
        }
                
        EntityManager em = emf.createEntityManager();
        AirportJPADAO airport_jpadao = new AirportJPADAO(em, Airport.class);
        EntityTransaction tx = em.getTransaction();
        Airport a = new Airport(iataCode, cityName, airportName, longitude, latitude);
        try {
            tx.begin();
            Airport b = airport_jpadao.create(a);
            tx.commit();
            return b;
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw new AirlineServiceException("Error al crear el aeropuerto");
        }finally{
            em.close();
        }
    }

    private boolean airportNameCheck(String iataCode, String cityName, String airportName, double longitude,
    double latitude)
    {
        if (iataCode.length() != 3 || cityName.isBlank() || cityName.isEmpty() || airportName.isBlank() || airportName.isEmpty()
        || longitude < -180  || longitude > 180 || latitude < -90 || latitude > 90) {
            return false;
        }
        
        for (int i = 0; i < iataCode.length(); i++) {
            if (iataCode.charAt(i) < 'A' || iataCode.charAt(i) > 'Z') {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<Airport> listAirports() {
        List<Airport> lista;

        EntityManager em = emf.createEntityManager();
        AirportJPADAO airport_jpadao = new AirportJPADAO(em, Airport.class);
        lista = airport_jpadao.findAll();

        return lista;
    }

    @Override
    public AircraftType createAircraft(String manufacturer, String model, int seatRows, int seatColumns)
            throws AirlineServiceException {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        AircraftTypeJPADAO aircraft_jpadao = new AircraftTypeJPADAO(em, AircraftType.class);

        if (!aircraftTypeNameCheck(manufacturer, model, seatRows, seatColumns)) {
            throw new AirlineServiceException("Error en los parametros de Aircraft");
        }
        AircraftType a = new AircraftType(manufacturer, model, seatRows, seatColumns);

        try {
            tx.begin();
            AircraftType b = aircraft_jpadao.create(a);
            tx.commit();
            return b;
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw new AirlineServiceException("Error al guardar el AircraftType");
        } finally{
            em.close();
        }
    }

    private boolean aircraftTypeNameCheck(String manufacturer, String model, int seatRows, int seatColumns){

        if (manufacturer == null || model == null) {
            return false;
        }
        if (manufacturer.isBlank() || manufacturer.isEmpty() || model.isBlank() || model.isEmpty()) {
            return false;
        }
        if (seatRows < 0 || seatRows < seatColumns || seatColumns < 0) {
            return false;
        }
        return true;
    }

    @Override
    public List<AircraftType> listAircraftTypes() {
        EntityManager em = emf.createEntityManager();
        AircraftTypeJPADAO at_jpadao = new AircraftTypeJPADAO(em, AircraftType.class);
        return at_jpadao.findAll();
    }

    @Override
    public Flight createFlight(String originAirportCode, String destinationAirportCode, Long aircraftTypeCode)
            throws AirlineServiceException {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        FlightJPADAO flight_jpadao = new FlightJPADAO(em, Flight.class);
        
        AirportJPADAO ap_jpadao = new AirportJPADAO(em, Airport.class);
        AircraftTypeJPADAO ac_jpadao = new AircraftTypeJPADAO(em, AircraftType.class);

        if (originAirportCode == null || destinationAirportCode == null || aircraftTypeCode == null) {
            throw new AirlineServiceException("Los parametros introducidos no son validos");
        }

        if (ap_jpadao.find(originAirportCode) == null ||ap_jpadao.find(destinationAirportCode) == null
            || ac_jpadao.find(aircraftTypeCode) == null || originAirportCode == destinationAirportCode) {
            throw new AirlineServiceException("Los parametros no se encuentran en la base de datos");
        }
        Flight flight = new Flight(ap_jpadao.find(originAirportCode), ap_jpadao.find(destinationAirportCode),
            ac_jpadao.find(aircraftTypeCode));
        try {
            tx.begin();
            Flight r = flight_jpadao.create(flight);
            tx.commit();
            return r;
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw new AirlineServiceException("Error al guardar el vuelo");
        }finally{
            em.close();
        }
    }

    /*
     * En las consultas, si de estas dependen pasos adicionales hay que hacerlo dentro de una 
     * transaccion
     */
    @Override
    public Flight findFlight(Long flightNumber) {
        EntityManager em = emf.createEntityManager();
        FlightJPADAO flight_jpadao = new FlightJPADAO(em, Flight.class);

        return flight_jpadao.find(flightNumber);
    }

    @Override
    public List<Flight> listFlights() {
        EntityManager em = emf.createEntityManager();
        FlightJPADAO flight_jpadao = new FlightJPADAO(em, Flight.class);
        
        return flight_jpadao.findAll();
    }

    @Override
    public Ticket purchaseTicket(String firstName, String lastName, Long flightNumber, LocalDate purchaseDate,
            LocalDate flightDate) throws AirlineServiceException {
            EntityManager em = emf.createEntityManager();
            EntityTransaction tx = em.getTransaction();
            TicketJPADAO tk_jpadao = new TicketJPADAO(em, Ticket.class);
            boolean ticketFinal = false;
            
            Random random = new Random();
            
            Flight f = findFlight(flightNumber);
            AircraftType a = f.getAircraft();
            int row = a.getSeatRows();
            int columns = a.getSeatColumns();
            //int precio = priceTicket();
            
            if (availableSeats(flightNumber, flightDate) <= 0) {
                throw new AirlineServiceException("No quedan asientos disponibles");
            }
            
            int precio = AirportQuery.priceTicketFinal(f, flightDate, purchaseDate, availableSeats(flightNumber, flightDate));
            try {
                tx.begin();
                Ticket t = new Ticket();
                List<Ticket> t_lista = f.getTickets();

                while (ticketFinal == false) {
                    t = new Ticket(firstName, lastName, random.nextInt(row), random.nextInt(columns), flightDate, precio, f);
                    System.out.println("Row = " + t.getSeatRow() + " Column = " + t.getSeatColumn());
                    if (t_lista.contains(t)) {
                        ticketFinal = false;
                    }else{
                        ticketFinal = true;
                    }
                }
                tk_jpadao.create(t);
                tx.commit();
                return t;
            } catch (Exception e) {
                if (tx.isActive()) {
                    tx.rollback();
                }
                throw new AirlineServiceException("Error al guardar el ticket");
            }finally {
                em.close();
                // TODO Un entityManager para toda la clase
                //Al comprobar la disponibilidad lo haria otro entityManager diferente al de esta funcion
            }
    }

    /*
    public void close(){
        emf.close();
        em.close();
    }
     */
    /*
     * private void()
     * 
     * if(this.emf == null || this.emf.isopen
     */
    private int priceTicket(){

        return 10;
    }

    @Override
    public int availableSeats(Long flightNumber, LocalDate flightDate) throws AirlineServiceException {
        EntityManager em = emf.createEntityManager();

        FlightJPADAO f_jpadao = new FlightJPADAO(em, Flight.class);
        TicketJPADAO t_jpadao = new TicketJPADAO(em, Ticket.class);

        Flight f = f_jpadao.find(flightNumber);
        List<Ticket> t_lista = t_jpadao.findByDate(flightDate, flightNumber);
        AircraftType a = f.getAircraft();
        int total = a.getSeatColumns() * a.getSeatRows();
        return (total - t_lista.size());
    }


    @Override
    public void cancelTicket(Long ticketNumber, LocalDate cancelDate) throws AirlineServiceException {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        TicketJPADAO t_jpadao = new TicketJPADAO(em, Ticket.class);

        try {
            tx.begin();
            Ticket t = t_jpadao.find(ticketNumber);
            t_jpadao.delete(t);
            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw new AirlineServiceException("Error al eliminar el elemento");
        }finally{
            em.close();
        }
    }

    public List<Ticket> listTicketOrderBy() {
        EntityManager em = emf.createEntityManager();
        TicketJPADAO t_jpadao = new TicketJPADAO(em, Ticket.class);
        
        return t_jpadao.findAllTicketsSortedByDate();
    }
    
}
