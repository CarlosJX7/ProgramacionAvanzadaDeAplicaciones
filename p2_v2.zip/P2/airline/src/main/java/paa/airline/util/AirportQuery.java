package paa.airline.util;

import org.json.JSONObject;

import paa.airline.business.AirlineService;
import paa.airline.model.AircraftType;
import paa.airline.model.Flight;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.math.MathContext;
import java.lang.Math;

public class AirportQuery {
    static ConcurrentHashMap<String, JSONObject> cache = new ConcurrentHashMap<>();

    private static JSONObject ensureCodeInCache(String iataCode) {
        if (cache.containsKey(iataCode.toUpperCase())) {
            return cache.get(iataCode.toUpperCase());
        }
        if (!iataCode.matches("[A-Za-z]{3}")) {
            return null;
        }

        try {
            Instant i = Instant.now();
            Thread.sleep(1000, 0); // very crude rate-limiting to avoid problems with the server if called several times in a row
            URLConnection conn = new URL("https://www.airport-data.com/api/ap_info.json?iata=" + iataCode.toUpperCase()).openConnection();
            JSONObject o = new JSONObject(new String(conn.getInputStream().readAllBytes()));
            if (o.isNull("location")) {
                System.err.println("Este aeropuerto no existe: " + iataCode);
                return null;
            } else {
                cache.put(iataCode.toUpperCase(), o);
                return o;
            }
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static String getName(String iataCode) {
        JSONObject o = ensureCodeInCache(iataCode);
        return o == null ? null : o.getString("name");
    }

    public static String getLocation(String iataCode) {
        JSONObject o = ensureCodeInCache(iataCode);
        return o == null ? null : o.getString("location");
    }

    public static Double getLongitude(String iataCode) {
        JSONObject o = ensureCodeInCache(iataCode);
        return o == null ? null : o.getDouble("longitude");
    }

    public static Double getLatitude(String iataCode) {
        JSONObject o = ensureCodeInCache(iataCode);
        return o == null ? null : o.getDouble("latitude");
    }

    public static double geodesicDistance(String iataCodeA, String iataCodeB) {
        JSONObject airportA = ensureCodeInCache(iataCodeA);
        JSONObject airportB = ensureCodeInCache(iataCodeB);
        double lonA = Math.toRadians(airportA.getDouble("longitude"));
        double lonB = Math.toRadians(airportB.getDouble("longitude"));
        double latA = Math.toRadians(airportA.getDouble("latitude"));
        double latB = Math.toRadians(airportB.getDouble("latitude"));
        return geodesicDistance(lonA, latA, lonB, latB);
    }

    public static double geodesicDistance(double lonA, double latA, double lonB, double latB) {
        final double r = 6371.009;
        return r * Math.acos(Math.sin(latA) * Math.sin(latB) + Math.cos(latA) * Math.cos(latB) * Math.cos(lonB - lonA));
    }

    private static double timePrice(LocalDate flightDate, LocalDate purchaseDate){

        //Dias que hay desde purchase hasta el dia del vuelo
        double t_left;
        //trush es el número de días antes de la fecha del vuelo en que los precios comienzan a subir.
        double t_rush;
        //tmax es las veces que el valor del billete podra ser incrementado
        double multiplier;
        //t_left = flightDate - purchaseDate;
        multiplier = AirlineService.tMax;
        t_left = ChronoUnit.DAYS.between(purchaseDate, flightDate);
        t_rush = AirlineService.tRush;
        double e = Math.exp(0.5 - ((49 * t_left * t_left) / (8 * t_rush * t_rush)));
        double a = (multiplier - 1) * 7 * t_left * e;
        double eyo = (multiplier - 1) * 7 * t_left;
        //double a = (multiplier - 1) * 7 * t_left * Math.exp(0.5- ((49 * t_left * t_left) / (8 * t_rush * t_rush)));
        double b = (a / (2 * t_rush)) + 1;
        System.out.println("e = " + e + " a = " + eyo + " timePrice = " + b);
        return b;
    }

    private static double soldPrice(int availableSeats, AircraftType aircraftType){
        int n_sold;
        int n_max_seats;
        double multiplier;

        n_max_seats = aircraftType.getSeatColumns() * aircraftType.getSeatRows();
        n_sold = n_max_seats - availableSeats;
        multiplier = AirlineService.oMax;

        double result = ((1 - multiplier) * Math.cos((n_sold * Math.PI) / (n_max_seats))) + multiplier + 1;
        return result / 2;
    }

    private static double distancePrice(Flight flight){
        double distance;
        distance = geodesicDistance(flight.getOrigin().getIataCode(), flight.getDestination().getIataCode());

        return (1000 + (10 * distance));
    }

    static public int priceTicketFinal(Flight flight, LocalDate flightDate, LocalDate purchaseDate, int availableSeats){
        double timePrice = timePrice(flightDate, purchaseDate);
        double soldPrice = soldPrice(availableSeats, flight.getAircraft());
        double distancePrice = distancePrice(flight);
        


        return (int)Math.round(timePrice * soldPrice * distancePrice);
    }


    public static void main(String[] args) {
        for (String iataCode: new String[] {"MAD", "lhr", "agp", "bcn"}) {
            System.out.println(getName(iataCode));
            System.out.println(getLocation(iataCode));
            System.out.println(getLongitude(iataCode));
            System.out.println(getLatitude(iataCode));
        }

        System.out.println(geodesicDistance("mad", "bcn"));

    }
}