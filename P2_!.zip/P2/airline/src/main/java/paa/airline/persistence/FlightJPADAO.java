package paa.airline.persistence;

import javax.persistence.EntityManager;

import paa.airline.model.Flight;

public class FlightJPADAO extends JPADAO<Flight, Long>{

    public FlightJPADAO(EntityManager em, Class<Flight> entityClass) {
        super(em, entityClass);
        //TODO Auto-generated constructor stub
    }
    
}
