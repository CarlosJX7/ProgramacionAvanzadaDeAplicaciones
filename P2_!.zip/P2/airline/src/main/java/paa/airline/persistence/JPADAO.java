package paa.airline.persistence;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import net.bytebuddy.asm.Advice.Local;

import java.time.LocalDate;
import java.util.List;

public class JPADAO<T, K> implements DAO<T, K> {
    protected EntityManager em;
    protected Class<T> clazz;

    public JPADAO(EntityManager em, Class<T> entityClass) {
        this.clazz = entityClass;
        this.em = em;
    }

    @Override
    public T find(K id) {
        // Complete este método
        return em.find(clazz, id);
    }

    @Override
    public T create(T t) {
        // Complete este método
        try {
            em.persist(t);
            em.flush();
            em.refresh(t);
            return t;
            
        } catch (EntityExistsException e) {
            throw new DAOException("La entidad ya existe");
        }

    }

    @Override
    public T update(T t) {
        // Complete este método
        return em.merge(t);

    }

    @Override
    public void delete(T t) {
        // Complete este método
        t = em.merge(t);
        em.remove(t);
    }

    @Override
    public List<T> findAll() {
        //Encontrar objetos de tipo T
        String jpql = "SELECT t FROM " + clazz.getSimpleName() + " t";
        TypedQuery<T> query = em.createQuery(jpql, clazz);
        return query.getResultList();
    }

    /*
    public List<T> findByDate(LocalDate date, Long flightNumber){
        //Encontrar objetos de tipo T para una fecha dada
        String jpql = "SELECT t FROM " + clazz.getSimpleName() + " t WHERE t.flightDate = :date AND t.flight.flightNumber = :flightNumber";
        TypedQuery<T> query = em.createQuery(jpql, clazz);
        query.setParameter("date", date);
        query.setParameter("flightNumber", flightNumber);
        return query.getResultList();
    }
     * 
     */
}
