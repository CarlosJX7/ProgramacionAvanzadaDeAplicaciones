package paa.airline.business;

public class AirlineServiceException extends Exception {

    public AirlineServiceException(String format) {
        super(format);
    }
}
