package paa.airline;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import paa.airline.business.JPAAirlineService;
import paa.airline.model.AircraftType;
import paa.airline.model.Airport;
import paa.airline.model.Flight;
import paa.airline.model.Ticket;
import paa.airline.business.AirlineService;
import paa.airline.business.AirlineServiceException;

public class JPATest {

    @Test
    void testCreateAirport() throws AirlineServiceException
    {
        JPAAirlineService jpa_as = new JPAAirlineService();
        Airport b = new Airport("MAD", "Madrid", "Barajas", 5, 10);

        assertNotNull(b);
        assertDoesNotThrow(() -> 
        b.equals(jpa_as.createAirport(b.getIataCode(), b.getCityName(), b.getAirportName(), b.getLongitude(), b.getLatitude()))
        );
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAirport("mAD", "Madrid", "", -200, 0);
            jpa_as.createAirport("MAD", "md", "Barajas", 5, 10);
            jpa_as.createAirport("mAD", "Madrid", "Barajas", 0, 0);
            jpa_as.createAirport("mAD", "Madrid", "Barajas", -200, 0);
            jpa_as.createAirport("mAD", "", "Barajas", -200, 0);
        });
        
    }

    @Test
    void testListAirport() throws AirlineServiceException{

        JPAAirlineService jpa_as = new JPAAirlineService();
        jpa_as.createAirport("AAA", "CiudadA", "Aeropuerto1", 4, 6);
        jpa_as.createAirport("BBB", "CiudadB", "Aeropuerto2", 4, 6);
        jpa_as.createAirport("CCC", "CiudadC", "Aeropuerto3", 4, 6);
        jpa_as.createAirport("DDD", "CiudadD", "Aeropuerto4", 4, 6);
        jpa_as.createAirport("EEE", "CiudadE", "Aeropuerto5", 4, 6);
        jpa_as.createAirport("FFF", "CiudadF", "Aeropuerto6", 4, 6);
        jpa_as.createAirport("GGG", "CiudadG", "Aeropuerto7", 4, 6);
        List<Airport> lista = jpa_as.listAirports();
        for (Airport airport : lista) {
            System.out.println(airport.getAirportName());
        }
    }

    @Test
    void createAircraftTypeTest() throws AirlineServiceException{
        JPAAirlineService jpa_as = new JPAAirlineService();

        assertDoesNotThrow(() ->
        {
            jpa_as.createAircraft("Manufacturer1", "Model1", 30, 0);
            jpa_as.createAircraft("Manufacturer2", "Model2", 1, 0);
            jpa_as.createAircraft("Manufacturer3", "Model3", 15, 5);
            jpa_as.createAircraft("Manufacturer4", "Model4", 100, 99);
        });
        
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", null, 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft(null, "Model", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("", "Model", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufaturer", "", 10, 0);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", "Model", 0, 10);
        });
        assertThrows(AirlineServiceException.class, () ->
        {
            jpa_as.createAircraft("Manufacturer", "Model", -10, 0);
        });
    
    }

    @Test
    void listAircraftTypes() throws AirlineServiceException {
        JPAAirlineService jpa_as = new JPAAirlineService();

        List<AircraftType> lista_test = new ArrayList<>();
        assertDoesNotThrow(() ->{
            AircraftType a = jpa_as.createAircraft("Manufacturer1", "Model1", 30, 0);
            AircraftType b = jpa_as.createAircraft("Manufacturer2", "Model2", 1, 0);
            AircraftType c = jpa_as.createAircraft("Manufacturer3", "Model3", 15, 5);
            AircraftType d = jpa_as.createAircraft("Manufacturer4", "Model4", 100, 99);
            lista_test.add(a);
            lista_test.add(b);
            lista_test.add(c);
            lista_test.add(d);
        });
        assertTrue(lista_test.equals(jpa_as.listAircraftTypes()));
    }

    @Test
    void createFlightTest() throws AirlineServiceException{

        JPAAirlineService as_jpa = new JPAAirlineService();
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        
        assertDoesNotThrow(() ->
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
            as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        });
        
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(null, aeropuerto_A.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(),null , avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), null);
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight("EEE", aeropuerto_B.getIataCode(), avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), "EEE", avion.getId());
        });
        assertThrows(AirlineServiceException.class, () -> 
        {
            as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), 123456L);
        });

    }

    @Test
    void findFlightTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();

        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        assertTrue(a.equals(as_jpa.findFlight(a.getFlightNumber())));
        assertTrue(b.equals(as_jpa.findFlight(b.getFlightNumber())));
        assertEquals(b, as_jpa.findFlight(b.getFlightNumber()));
        assertNotEquals(a, b);
    }

    @Test
    void listFlightsTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        Airport aeropuerto_C = as_jpa.createAirport("CCC", "CiudadC", "AeropuertoC", 10, 10);

        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 10, 9);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        Flight c = as_jpa.createFlight(aeropuerto_C.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());
        Flight d = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_C.getIataCode(), avion.getId());
        Flight e = as_jpa.createFlight(aeropuerto_C.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight f = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_C.getIataCode(), avion.getId());

        List<Flight> lista_test = new ArrayList<>();
        lista_test.add(a);
        lista_test.add(b);
        lista_test.add(c);
        lista_test.add(d);
        lista_test.add(e);
        lista_test.add(f);

        assertEquals(lista_test, as_jpa.listFlights());
    }

    @Test
    void arrayTest(){
    boolean [][] asiento = new boolean[10][10];

    asiento[0][0] = true;

    assertTrue(asiento[0][0]);
    assertFalse(asiento[0][1]);


    }
    

    @Test
    void purchaseTicketTest() throws AirlineServiceException{
        JPAAirlineService as_jpa = new JPAAirlineService();

        
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 2, 2);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());

        //int n = a.getTickets().size();
        //System.out.println(a.getTickets().size());
        //a.getTickets().size();
        
        //Hay que actualizar el objeto para conseguir sus datos
        List<Ticket> t_lista = as_jpa.findFlight(a.getFlightNumber()).getTickets();
        System.out.println("\n\nTEST\n\n" + t_lista.size());
        System.out.println(t_lista);

    }

    @Test
    void availableSeatsTest() throws AirlineServiceException{

        JPAAirlineService as_jpa = new JPAAirlineService();

        
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 10, 10);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 10, 10);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 3, 3);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

        System.out.println(as_jpa.availableSeats(a.getFlightNumber(), LocalDate.now()));

        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", a.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());
        as_jpa.purchaseTicket("Jhan", "Jhon", b.getFlightNumber(), LocalDate.now(), LocalDate.now());

        System.out.println(as_jpa.availableSeats(a.getFlightNumber(), LocalDate.now()));
    }

    @Test
    void fillTest() throws AirlineServiceException{

        JPAAirlineService as_jpa = new JPAAirlineService();

        
        Airport aeropuerto_A = as_jpa.createAirport("AAA", "CiudadA", "AeropuertoA", 4, 4);
        Airport aeropuerto_B = as_jpa.createAirport("BBB", "CiudadB", "AeropuertoB", 4, 4);
        AircraftType avion = as_jpa.createAircraft("Manufacturer1", "Model1", 4, 4);
        

        Flight a = as_jpa.createFlight(aeropuerto_A.getIataCode(), aeropuerto_B.getIataCode(), avion.getId());
        Flight b = as_jpa.createFlight(aeropuerto_B.getIataCode(), aeropuerto_A.getIataCode(), avion.getId());

    }


}
