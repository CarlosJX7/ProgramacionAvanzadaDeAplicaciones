package paa.airline.business;

import org.junit.jupiter.api.Test;

public class JPAAirlineServiceTest {
    @Test
    void testAvailableSeats() {

    }

    @Test
    void testCancelTicket() {

    }

    @Test
    void testCreateAircraft() {

    }

    @Test
    void testCreateAirport() {

    }

    @Test
    void testCreateFlight() {

    }

    @Test
    void testFindFlight() {

    }

    @Test
    void testListAircraftTypes() {

    }

    @Test
    void testListAirports() {

    }

    @Test
    void testListFlights() {

    }

    @Test
    void testPurchaseTicket() {

    }
}
